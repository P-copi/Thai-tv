# Thai TV Player v1.1

Android IPTV player for Thai M3U/M3U8 playlists.

Features:
- Load default GitHub playlist
- Load an M3U/M3U8 file from the phone using Android file picker
- Enter any M3U/M3U8 playlist URL
- HLS playback with Media3 ExoPlayer
- Browser-like User-Agent and redirects enabled
- Playback errors shown on screen for troubleshooting
- Channel logos from tvg-logo
- Remembers the last URL playlist

Package: com.pcopi.thaitv
Version: 1.1 (versionCode 2)
