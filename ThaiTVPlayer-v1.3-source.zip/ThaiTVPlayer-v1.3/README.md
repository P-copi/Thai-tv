# Thai TV Player v1.3
- Version code 13 / version 1.3
- Thai TV Player name and new adaptive TV/play icon
- HLS `.m3u8` and DASH `.mpd`
- Landscape while watching
- Playback error display
- Playlist: https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u

DASH uses standard Media3 playback and the MPD's own content-protection signaling. No external DRM key is embedded.
