# Thai TV Player v1.4
- Version code 14 / version 1.4
- Displays `tvg-logo` from the M3U playlist without delaying playback.
- HLS `.m3u8` and DASH `.mpd` via Media3.
- Landscape while watching.
- Clear playback error display.
- Playlist: https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u

## Build without a PC
Upload this project to GitHub, then open **Actions → Build APK → Run workflow**. The generated debug APK is uploaded as a workflow artifact.
