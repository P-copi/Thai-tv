package com.pcopi.thaitv;

import android.app.*;
import android.os.*;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.*;
import androidx.media3.exoplayer.*;
import androidx.media3.ui.PlayerView;
import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {
    static class Channel {
        String name, url, logo;
        Channel(String n, String u, String l) { name=n; url=u; logo=l; }
    }

    ArrayList<Channel> channels = new ArrayList<>();
    ExecutorService ex = Executors.newFixedThreadPool(4);
    LinearLayout box;
    TextView status, error;
    View list, playerPanel;
    PlayerView pv;
    ExoPlayer player;

    public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(com.pcopi.thaitv.R.layout.activity_main);
        box=findViewById(R.id.channelContainer);
        status=findViewById(R.id.statusText);
        error=findViewById(R.id.errorText);
        list=findViewById(R.id.listPanel);
        playerPanel=findViewById(R.id.playerPanel);
        pv=findViewById(R.id.playerView);
        load();
    }

    void load() {
        ex.execute(() -> {
            HttpURLConnection c=null;
            try {
                c=(HttpURLConnection)new URL(getString(R.string.playlist_url)).openConnection();
                c.setConnectTimeout(8000);
                c.setReadTimeout(12000);
                c.setRequestProperty("User-Agent","ThaiTVPlayer/1.4");
                BufferedReader r=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
                String s,n=null,logo=null;
                while((s=r.readLine())!=null) {
                    s=s.trim();
                    if(s.startsWith("#EXTINF")) {
                        int i=s.indexOf(',');
                        n=i>=0?s.substring(i+1).trim():"TV";
                        logo=getAttr(s,"tvg-logo");
                    } else if(!s.isEmpty()&&!s.startsWith("#")&&n!=null) {
                        channels.add(new Channel(n,s,logo));
                        n=null; logo=null;
                    }
                }
                r.close();
                runOnUiThread(this::showChannels);
            } catch(Exception e) {
                runOnUiThread(()->status.setText("โหลด Playlist ไม่สำเร็จ: "+shortError(e)));
            } finally { if(c!=null)c.disconnect(); }
        });
    }

    String getAttr(String line,String key) {
        String p=key+"=";
        int i=line.indexOf(p);
        if(i<0)return "";
        i+=p.length();
        if(i<line.length()&&(line.charAt(i)=='\"'||line.charAt(i)=='\\'')) {
            char q=line.charAt(i++); int j=line.indexOf(q,i);
            return j>=0?line.substring(i,j):line.substring(i);
        }
        int j=line.indexOf(' ',i);
        return j>=0?line.substring(i,j):line.substring(i);
    }

    void showChannels() {
        status.setText("พบ "+channels.size()+" ช่อง");
        box.removeAllViews();
        for(Channel ch:channels) addChannelView(ch);
    }

    void addChannelView(Channel ch) {
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        int pad=dp(8);
        row.setPadding(pad,pad,pad,pad);

        ImageView logo=new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        row.addView(logo,new LinearLayout.LayoutParams(dp(58),dp(58)));

        Button b=new Button(this);
        b.setText(ch.name);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER_VERTICAL|Gravity.START);
        b.setOnClickListener(v->play(ch));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,dp(58),1f);
        bp.leftMargin=dp(8);
        row.addView(b,bp);
        box.addView(row,new LinearLayout.LayoutParams(-1,-2));

        if(ch.logo!=null&&!ch.logo.isEmpty()) {
            ex.execute(() -> {
                Bitmap bmp=downloadBitmap(ch.logo);
                if(bmp!=null) runOnUiThread(() -> logo.setImageBitmap(bmp));
            });
        }
    }

    Bitmap downloadBitmap(String u) {
        HttpURLConnection c=null;
        try {
            c=(HttpURLConnection)new URL(u).openConnection();
            c.setConnectTimeout(5000); c.setReadTimeout(7000);
            c.setRequestProperty("User-Agent","ThaiTVPlayer/1.4");
            c.connect();
            if(c.getResponseCode()/100!=2)return null;
            return BitmapFactory.decodeStream(c.getInputStream());
        } catch(Exception ignored) { return null; }
        finally { if(c!=null)c.disconnect(); }
    }

    void play(Channel ch) {
        list.setVisibility(View.GONE);
        playerPanel.setVisibility(View.VISIBLE);
        error.setVisibility(View.GONE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        release();
        player=new ExoPlayer.Builder(this).build();
        pv.setPlayer(player);
        player.addListener(new Player.Listener(){
            public void onPlayerError(PlaybackException e){
                error.setText("เปิดช่องไม่ได้\n"+ch.name+"\n"+e.errorCodeName);
                error.setVisibility(View.VISIBLE);
            }
        });
        MediaItem.Builder m=new MediaItem.Builder().setUri(Uri.parse(ch.url));
        String u=ch.url.toLowerCase(Locale.US);
        if(u.contains(".mpd"))m.setMimeType(MimeTypes.APPLICATION_MPD);
        else if(u.contains(".m3u8"))m.setMimeType(MimeTypes.APPLICATION_M3U8);
        player.setMediaItem(m.build());
        player.prepare();
        player.play();
    }

    String shortError(Exception e){ return e.getMessage()==null?e.getClass().getSimpleName():e.getMessage(); }
    int dp(int v){ return Math.round(v*getResources().getDisplayMetrics().density); }

    public void onBackPressed(){
        if(playerPanel.getVisibility()==View.VISIBLE){
            release(); playerPanel.setVisibility(View.GONE); list.setVisibility(View.VISIBLE);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT);
        } else super.onBackPressed();
    }
    void release(){ if(player!=null){player.release();player=null;} pv.setPlayer(null); }
    protected void onDestroy(){ release(); ex.shutdownNow(); super.onDestroy(); }
}
