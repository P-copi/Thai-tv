package com.pcopi.thaitv;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final String DEFAULT_PLAYLIST =
            "https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u";
    private static final String PREFS = "thai_tv_player";
    private static final String KEY_SOURCE = "playlist_source";
    private static final String DEFAULT_UA =
            "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 " +
            "Chrome/140.0 Mobile Safari/537.36";

    private PlayerView playerView;
    private ExoPlayer player;
    private TextView status;
    private ChannelAdapter adapter;
    private final ArrayList<Channel> channels = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private SharedPreferences prefs;
    private String playlistSource = DEFAULT_PLAYLIST;

    private final ActivityResultLauncher<Intent> openPlaylist =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() != RESULT_OK || result.getData() == null) return;
                Uri uri = result.getData().getData();
                if (uri == null) return;
                try {
                    getContentResolver().takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) { }
                loadLocalPlaylist(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        playlistSource = prefs.getString(KEY_SOURCE, DEFAULT_PLAYLIST);

        playerView = findViewById(R.id.player);
        status = findViewById(R.id.status);
        Button refresh = findViewById(R.id.refresh);
        Button local = findViewById(R.id.local_file);
        Button url = findViewById(R.id.playlist_url);
        RecyclerView list = findViewById(R.id.list);

        DefaultHttpDataSource.Factory httpFactory = new DefaultHttpDataSource.Factory()
                .setUserAgent(DEFAULT_UA)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(20000)
                .setAllowCrossProtocolRedirects(true)
                .setDefaultRequestProperties(java.util.Collections.singletonMap("Accept", "*/*"));
        DefaultDataSource.Factory dataSourceFactory = new DefaultDataSource.Factory(this, httpFactory);
        DefaultMediaSourceFactory mediaSourceFactory = new DefaultMediaSourceFactory(dataSourceFactory);

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(mediaSourceFactory)
                .build();
        playerView.setPlayer(player);
        playerView.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) {
                    status.setText("กำลังเชื่อมต่อสัญญาณ…");
                } else if (state == Player.STATE_READY) {
                    Channel c = getCurrentChannel();
                    if (c != null) status.setText("กำลังเล่น: " + c.name);
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                String detail = error.errorCodeName;
                if (error.getCause() != null && error.getCause().getMessage() != null) {
                    detail += " • " + error.getCause().getMessage();
                }
                status.setText("เล่นไม่ได้: " + detail);
                Toast.makeText(MainActivity.this,
                        "ช่องนี้เล่นไม่ได้ — ลองช่องอื่นหรือดูรายละเอียดด้านบน",
                        Toast.LENGTH_LONG).show();
            }
        });

        adapter = new ChannelAdapter();
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        refresh.setOnClickListener(v -> loadPlaylistUrl(playlistSource));
        local.setOnClickListener(v -> chooseLocalPlaylist());
        url.setOnClickListener(v -> showUrlDialog());

        loadPlaylistUrl(playlistSource);
    }

    private void chooseLocalPlaylist() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/vnd.apple.mpegurl",
                "audio/x-mpegurl",
                "application/x-mpegURL",
                "text/plain",
                "application/octet-stream"
        });
        openPlaylist.launch(intent);
    }

    private void showUrlDialog() {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("https://.../playlist.m3u8");
        input.setText(playlistSource.startsWith("http") ? playlistSource : "");
        input.setSelectAllOnFocus(true);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad / 2, pad, pad / 2);

        new AlertDialog.Builder(this)
                .setTitle("เพิ่ม Playlist จาก URL")
                .setMessage("ใส่ลิงก์ .m3u หรือ .m3u8 แล้วกดโหลด")
                .setView(input)
                .setNegativeButton("ยกเลิก", null)
                .setPositiveButton("โหลด", (dialog, which) -> {
                    String value = input.getText().toString().trim();
                    if (!value.startsWith("http://") && !value.startsWith("https://")) {
                        Toast.makeText(this, "URL ต้องขึ้นต้นด้วย http:// หรือ https://", Toast.LENGTH_LONG).show();
                        return;
                    }
                    loadPlaylistUrl(value);
                })
                .show();
    }

    private void loadPlaylistUrl(String urlString) {
        playlistSource = urlString;
        prefs.edit().putString(KEY_SOURCE, playlistSource).apply();
        status.setText("กำลังโหลด Playlist…");
        executor.execute(() -> {
            try {
                ArrayList<Channel> parsed = parseRemotePlaylist(urlString);
                runOnUiThread(() -> showChannels(parsed, "URL"));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("โหลด Playlist ไม่สำเร็จ: " + safeMessage(e)));
            }
        });
    }

    private ArrayList<Channel> parseRemotePlaylist(String urlString) throws Exception {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(15000);
            connection.setReadTimeout(20000);
            connection.setInstanceFollowRedirects(true);
            connection.setRequestProperty("User-Agent", DEFAULT_UA);
            connection.setRequestProperty("Accept", "*/*");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("HTTP " + code);
            try (InputStream in = connection.getInputStream()) {
                return parsePlaylist(new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private void loadLocalPlaylist(Uri uri) {
        status.setText("กำลังอ่านไฟล์ Playlist…");
        executor.execute(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("เปิดไฟล์ไม่ได้");
                String name = String.valueOf(uri.getLastPathSegment()).toLowerCase(Locale.US);
                if (!(name.endsWith(".m3u") || name.endsWith(".m3u8"))) {
                    // Some document providers hide the real filename; still allow it if content is M3U.
                }
                ArrayList<Channel> parsed = parsePlaylist(
                        new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8)));
                prefs.edit().remove(KEY_SOURCE).apply();
                playlistSource = uri.toString();
                runOnUiThread(() -> showChannels(parsed, "ไฟล์ในเครื่อง"));
            } catch (Exception e) {
                runOnUiThread(() -> status.setText("อ่านไฟล์ไม่ได้: " + safeMessage(e)));
            }
        });
    }

    private ArrayList<Channel> parsePlaylist(BufferedReader reader) throws IOException {
        ArrayList<Channel> out = new ArrayList<>();
        String info = null;
        String logo = "";
        String group = "";
        String userAgent = null;
        String referer = null;
        String line;

        while ((line = reader.readLine()) != null) {
            line = line.replace("\ufeff", "").trim();
            if (line.isEmpty()) continue;

            if (line.startsWith("#EXTINF:")) {
                info = line;
                logo = getAttribute(line, "tvg-logo");
                group = getAttribute(line, "group-title");
                userAgent = null;
                referer = null;
                continue;
            }

            String lower = line.toLowerCase(Locale.US);
            if (info != null && lower.startsWith("#extvlcopt:http-user-agent=")) {
                userAgent = line.substring(line.indexOf('=') + 1).trim();
                continue;
            }
            if (info != null && (lower.startsWith("#extvlcopt:http-referrer=")
                    || lower.startsWith("#extvlcopt:http-referer="))) {
                referer = line.substring(line.indexOf('=') + 1).trim();
                continue;
            }
            if (info != null && line.startsWith("#EXTHTTP:")) {
                continue;
            }

            if (info != null && !line.startsWith("#")) {
                String name = info.contains(",") ? info.substring(info.indexOf(',') + 1).trim() : "ช่องทีวี";
                if (!line.isEmpty()) out.add(new Channel(name, line, logo, group, userAgent, referer));
                info = null;
            }
        }
        return out;
    }

    private String getAttribute(String line, String key) {
        String marker = key + "=\"";
        int p = line.indexOf(marker);
        if (p < 0) return "";
        int s = p + marker.length();
        int e = line.indexOf('"', s);
        return e > s ? line.substring(s, e) : "";
    }

    private void showChannels(ArrayList<Channel> parsed, String sourceName) {
        channels.clear();
        channels.addAll(parsed);
        adapter.notifyDataSetChanged();
        if (channels.isEmpty()) {
            status.setText("ไม่พบช่องใน Playlist");
        } else {
            status.setText("พบ " + channels.size() + " ช่อง • " + sourceName + " • แตะช่องเพื่อเล่น");
        }
    }

    private void play(Channel c) {
        try {
            Uri uri = Uri.parse(c.url);
            MediaItem.Builder builder = new MediaItem.Builder().setUri(uri);
            if (c.url.toLowerCase(Locale.US).contains(".m3u8")) {
                builder.setMimeType(MimeTypes.APPLICATION_M3U8);
            }
            if (c.userAgent != null && !c.userAgent.isEmpty()) {
                builder.setUri(uri);
            }
            MediaItem item = builder.build();
            player.setMediaItem(item);
            player.prepare();
            player.play();
            status.setText("กำลังเชื่อมต่อ: " + c.name);
        } catch (Exception e) {
            status.setText("เปิดช่องไม่ได้: " + safeMessage(e));
        }
    }

    private Channel getCurrentChannel() {
        int index = player.getCurrentMediaItemIndex();
        return index >= 0 && index < channels.size() ? channels.get(index) : null;
    }

    private String safeMessage(Exception e) {
        String m = e.getMessage();
        return m == null || m.isEmpty() ? e.getClass().getSimpleName() : m;
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        if (player != null) player.release();
        super.onDestroy();
    }

    class Channel {
        String name, url, logo, group, userAgent, referer;
        Channel(String n, String u, String l, String g, String ua, String ref) {
            name = n; url = u; logo = l; group = g; userAgent = ua; referer = ref;
        }
    }

    class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH> {
        @Override
        public VH onCreateViewHolder(android.view.ViewGroup parent, int viewType) {
            LinearLayout row = new LinearLayout(MainActivity.this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(16, 10, 16, 10);

            ImageView image = new ImageView(MainActivity.this);
            image.setLayoutParams(new LinearLayout.LayoutParams(64, 64));
            image.setScaleType(ImageView.ScaleType.CENTER_INSIDE);

            TextView text = new TextView(MainActivity.this);
            text.setTextSize(17);
            text.setPadding(16, 0, 0, 0);
            row.addView(image);
            row.addView(text, new LinearLayout.LayoutParams(0, -2, 1));
            return new VH(row, image, text);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {
            Channel c = channels.get(position);
            holder.text.setText(c.name);
            holder.image.setImageResource(android.R.drawable.ic_media_play);
            if (!c.logo.isEmpty()) {
                Glide.with(MainActivity.this)
                        .load(c.logo)
                        .placeholder(android.R.drawable.ic_media_play)
                        .error(android.R.drawable.ic_media_play)
                        .into(holder.image);
            }
            holder.itemView.setOnClickListener(v -> play(c));
        }

        @Override public int getItemCount() { return channels.size(); }

        class VH extends RecyclerView.ViewHolder {
            ImageView image; TextView text;
            VH(View v, ImageView i, TextView t) { super(v); image = i; text = t; }
        }
    }
}
