package com.pcopi.thaitv;

import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private static final String PLAYLIST =
            "https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u";

    private ExoPlayer player;
    private PlayerView playerView;
    private TextView status;
    private Button refresh;
    private RecyclerView list;

    private final ArrayList<Channel> channels = new ArrayList<>();
    private ChannelAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        try {
            setContentView(R.layout.activity_main);

            playerView = findViewById(R.id.player);
            status = findViewById(R.id.status);
            refresh = findViewById(R.id.refresh);
            list = findViewById(R.id.list);

            if (playerView == null || status == null ||
                    refresh == null || list == null) {
                showError("หา View ใน activity_main.xml ไม่ครบ");
                return;
            }

            player = new ExoPlayer.Builder(this).build();
            playerView.setPlayer(player);

            adapter = new ChannelAdapter();
            list.setLayoutManager(new LinearLayoutManager(this));
            list.setAdapter(adapter);

            refresh.setOnClickListener(v -> loadPlaylist());

            status.setText("พร้อมโหลด Playlist");
            
            // โหลด Playlist หลังจากหน้าจอสร้างเสร็จ
            loadPlaylist();

        } catch (Exception e) {
            showError("เปิดแอปผิดพลาด: " + e.getMessage());
        }
    }

    private void loadPlaylist() {

        if (status != null) {
            status.setText("กำลังโหลด Playlist...");
        }

        new Thread(() -> {

            ArrayList<Channel> result = new ArrayList<>();

            try {

                URL url = new URL(PLAYLIST);

                HttpURLConnection connection =
                        (HttpURLConnection) url.openConnection();

                connection.setConnectTimeout(15000);
                connection.setReadTimeout(20000);
                connection.setRequestMethod("GET");

                try (BufferedReader reader =
                             new BufferedReader(
                                     new InputStreamReader(
                                             connection.getInputStream()))) {

                    String line;
                    String info = null;

                    while ((line = reader.readLine()) != null) {

                        line = line.trim();

                        if (line.startsWith("#EXTINF:")) {
                            info = line;

                        } else if (info != null
                                && !line.startsWith("#")
                                && !line.isEmpty()) {

                            result.add(parseChannel(info, line));
                            info = null;
                        }
                    }
                }

                connection.disconnect();

                runOnUiThread(() -> {

                    channels.clear();
                    channels.addAll(result);

                    if (adapter != null) {
                        adapter.notifyDataSetChanged();
                    }

                    if (status != null) {
                        status.setText(
                                "พบ " + channels.size()
                                        + " ช่อง • แตะช่องเพื่อเล่น"
                        );
                    }
                });

            } catch (Exception e) {

                runOnUiThread(() -> {

                    if (status != null) {
                        status.setText(
                                "โหลด Playlist ไม่ได้: "
                                        + e.getMessage()
                        );
                    }

                    Toast.makeText(
                            MainActivity.this,
                            "โหลด Playlist ไม่สำเร็จ",
                            Toast.LENGTH_LONG
                    ).show();
                });
            }

        }).start();
    }

    private Channel parseChannel(String info, String url) {

        String name = "ไม่ทราบชื่อ";
        String logo = "";
        String group = "";

        int comma = info.indexOf(",");

        if (comma >= 0 && comma + 1 < info.length()) {
            name = info.substring(comma + 1).trim();
        }

        int logoStart = info.indexOf("tvg-logo=\"");

        if (logoStart >= 0) {

            int start = logoStart + 10;
            int end = info.indexOf("\"", start);

            if (end > start) {
                logo = info.substring(start, end);
            }
        }

        int groupStart = info.indexOf("group-title=\"");

        if (groupStart >= 0) {

            int start = groupStart + 13;
            int end = info.indexOf("\"", start);

            if (end > start) {
                group = info.substring(start, end);
            }
        }

        return new Channel(name, url, logo, group);
    }

    private void play(Channel channel) {

        if (player == null) {
            Toast.makeText(
                    this,
                    "ตัวเล่นวิดีโอยังไม่พร้อม",
                    Toast.LENGTH_SHORT
            ).show();
            return;
        }

        try {

            MediaItem mediaItem =
                    MediaItem.fromUri(Uri.parse(channel.url));

            player.setMediaItem(mediaItem);
            player.prepare();
            player.play();

            if (status != null) {
                status.setText("กำลังเล่น: " + channel.name);
            }

        } catch (Exception e) {

            Toast.makeText(
                    this,
                    "เปิดช่องไม่ได้: " + e.getMessage(),
                    Toast.LENGTH_LONG
            ).show();
        }
    }

    private void showError(String message) {

        Toast.makeText(
                this,
                message,
                Toast.LENGTH_LONG
        ).show();
    }

    @Override
    protected void onDestroy() {

        if (player != null) {
            player.release();
            player = null;
        }

        super.onDestroy();
    }

    private static class Channel {

        String name;
        String url;
        String logo;
        String group;

        Channel(String name, String url, String logo, String group) {
            this.name = name;
            this.url = url;
            this.logo = logo;
            this.group = group;
        }
    }

    private class ChannelAdapter
            extends RecyclerView.Adapter<ChannelAdapter.VH> {

        @Override
        public VH onCreateViewHolder(
                android.view.ViewGroup parent,
                int viewType) {

            LinearLayout row =
                    new LinearLayout(MainActivity.this);

            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(12, 8, 12, 8);

            ImageView image =
                    new ImageView(MainActivity.this);

            image.setLayoutParams(
                    new LinearLayout.LayoutParams(64, 64)
            );

            TextView text =
                    new TextView(MainActivity.this);

            text.setTextSize(17);
            text.setPadding(14, 0, 0, 0);

            row.addView(image);
            row.addView(
                    text,
                    new LinearLayout.LayoutParams(
                            0,
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            1
                    )
            );

            return new VH(row, image, text);
        }

        @Override
        public void onBindViewHolder(VH holder, int position) {

            Channel channel = channels.get(position);

            holder.text.setText(channel.name);

            if (channel.logo != null
                    && !channel.logo.isEmpty()) {

                Glide.with(MainActivity.this)
                        .load(channel.logo)
                        .into(holder.image);

            } else {

                holder.image.setImageDrawable(null);
            }

            holder.itemView.setOnClickListener(
                    v -> play(channel)
            );
        }

        @Override
        public int getItemCount() {
            return channels.size();
        }

        class VH extends RecyclerView.ViewHolder {

            ImageView image;
            TextView text;

            VH(
                    View view,
                    ImageView image,
                    TextView text) {

                super(view);

                this.image = image;
                this.text = text;
            }
        }
    }
}
