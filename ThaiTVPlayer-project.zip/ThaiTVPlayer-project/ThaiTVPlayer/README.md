# Thai TV Player
Android IPTV/M3U player for the Thai TV playlist.

Default playlist:
https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u

Features:
- Loads M3U from GitHub URL
- Shows channel names and logos
- Plays HLS .m3u8 with AndroidX Media3 ExoPlayer
- Refresh button

Build: Android Studio / GitHub Actions, JDK 17.
