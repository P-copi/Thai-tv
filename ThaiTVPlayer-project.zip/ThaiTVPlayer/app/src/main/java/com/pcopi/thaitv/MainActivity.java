package com.pcopi.thaitv;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;
import androidx.media3.common.MediaItem;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import java.io.*;
import java.net.*;
import java.util.*;
import android.view.*;
import android.widget.ImageView;
import com.bumptech.glide.Glide;

public class MainActivity extends AppCompatActivity {
    static final String PLAYLIST = "https://raw.githubusercontent.com/P-copi/Thai-tv/main/thai-tv-new.m3u";
    ExoPlayer player; PlayerView playerView; TextView status; ArrayList<Channel> channels=new ArrayList<>(); ChannelAdapter adapter;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
        playerView=findViewById(R.id.player); status=findViewById(R.id.status); Button refresh=findViewById(R.id.refresh);
        player=new ExoPlayer.Builder(this).build(); playerView.setPlayer(player);
        adapter=new ChannelAdapter(); RecyclerView list=findViewById(R.id.list); list.setLayoutManager(new LinearLayoutManager(this)); list.setAdapter(adapter);
        refresh.setOnClickListener(v->loadPlaylist()); loadPlaylist(); }
    void loadPlaylist(){ status.setText("กำลังโหลด Playlist..."); new Thread(()->{try{
        URL u=new URL(PLAYLIST); BufferedReader r=new BufferedReader(new InputStreamReader(u.openStream())); String line; String info=null; ArrayList<Channel> out=new ArrayList<>();
        while((line=r.readLine())!=null){line=line.trim(); if(line.startsWith("#EXTINF:")){info=line;} else if(info!=null&&!line.startsWith("#")&&!line.isEmpty()){out.add(parse(info,line)); info=null;}}
        r.close(); runOnUiThread(()->{channels.clear();channels.addAll(out);adapter.notifyDataSetChanged();status.setText("พบ "+channels.size()+" ช่อง • แตะช่องเพื่อเล่น"); if(!channels.isEmpty()) play(channels.get(0));});
      }catch(Exception e){runOnUiThread(()->status.setText("โหลดไม่ได้: "+e.getMessage()));}}).start(); }
    Channel parse(String info,String url){String name=info.substring(info.indexOf(",")+1).trim(); String logo=""; int p=info.indexOf("tvg-logo=\""); if(p>=0){int s=p+10,e=info.indexOf("\"",s);if(e>s)logo=info.substring(s,e);} String group="";p=info.indexOf("group-title=\"");if(p>=0){int s=p+13,e=info.indexOf("\"",s);if(e>s)group=info.substring(s,e);} return new Channel(name,url,logo,group);}
    void play(Channel c){player.setMediaItem(MediaItem.fromUri(c.url));player.prepare();player.play();status.setText("กำลังเล่น: "+c.name);}
    @Override protected void onDestroy(){player.release();super.onDestroy();}
    class Channel {String name,url,logo,group;Channel(String n,String u,String l,String g){name=n;url=u;logo=l;group=g;}}
    class ChannelAdapter extends RecyclerView.Adapter<ChannelAdapter.VH>{
      public VH onCreateViewHolder(android.view.ViewGroup p,int v){LinearLayout row=new LinearLayout(MainActivity.this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(12,8,12,8);ImageView img=new ImageView(MainActivity.this);img.setLayoutParams(new LinearLayout.LayoutParams(64,64));TextView t=new TextView(MainActivity.this);t.setTextSize(17);t.setPadding(14,0,0,0);row.addView(img);row.addView(t,new LinearLayout.LayoutParams(-1,-2));return new VH(row,img,t);}
      public void onBindViewHolder(VH h,int i){Channel c=channels.get(i);h.t.setText(c.name);if(!c.logo.isEmpty())Glide.with(MainActivity.this).load(c.logo).into(h.img);h.itemView.setOnClickListener(v->play(c));}
      public int getItemCount(){return channels.size();} class VH extends RecyclerView.ViewHolder{ImageView img;TextView t;VH(View v,ImageView i,TextView t){super(v);img=i;this.t=t;}}
    }
}
